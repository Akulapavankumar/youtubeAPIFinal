﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using YouTubeEmbed.Models;

namespace YouTubeEmbed.Pages
{
    public partial class YouTubeChannelPage : ContentPage
    {

        public YouTubeChannelPage()
        {
            InitializeComponent();
        }

        public void PlayVideo(object sender, SelectedItemChangedEventArgs e)
        {
            var video = e.SelectedItem as YouTubeItem;
            // Navigation.PushAsync(new WebViewPage(video.VideoId));
            Navigation.PushAsync(new VideoPage(video.VideoId));
            //if (video.VideoId != null)
            //{
            //    Device.OpenUri(new Uri("https://www.youtube.com/watch?v=" + video.VideoId));
            //}
            //else
            //{
            //    DisplayAlert("Pavan","ID Is Null !", "ok");
            //}
        }

    }
}
